#include <iostream>

int main() {
    std::cout << "Hi" << std::endl;
    return 0;
}
